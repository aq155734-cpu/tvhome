# Mi Home (launcher para Android TV)

## Compilar
1. Abre esta carpeta con Android Studio (File > Open). Deja que sincronice Gradle.
2. Build > Build APK(s). El APK queda en app/build/outputs/apk/debug/app-debug.apk

## Instalar en la tele
    adb connect IP_DE_LA_TELE:5555
    adb install -r app-debug.apk
    adb shell cmd package set-home-activity com.andy.tvhome/.MainActivity

Para volver al home original:
    adb shell pm clear com.andy.tvhome   (o desinstala la app)

## Personalizar
Arriba de MainActivity.kt: nombre, frase, apps favoritas y colores.
Fondo con imagen: copia tu imagen como app/src/main/res/drawable-nodpi/bg.png (o .jpg) y recompila.
