package com.andy.tvhome

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// ===== PERSONALIZA AQUÍ =====
private const val USER_NAME = "Andy"
private const val TAGLINE = "El control remoto es tuyo. Úsalo con sabiduría."
// Apps que aparecen primero (en este orden). Agrega los paquetes que quieras.
private val FAVORITES = listOf(
    "com.netflix.ninja",
    "com.google.android.youtube.tv",
    "com.amazon.amazonvideo.webapp",
    "com.disney.disneyplus",
    "com.hbo.hbonow",
    "com.wbd.stream",
    "com.spotify.tv.android"
)
private const val COLOR_TOP = "#1B2A4A"
private const val COLOR_BOTTOM = "#0A0E1A"
// ============================

data class AppItem(
    val label: String,
    val intent: Intent,
    val image: Drawable,
    val isBanner: Boolean
)

class MainActivity : Activity() {

    private lateinit var greeting: TextView
    private lateinit var clock: TextView
    private lateinit var recycler: RecyclerView
    private val adapter = AppAdapter()
    private val handler = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() {
            updateTexts()
            handler.postDelayed(this, 15_000)
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(buildUi())
    }

    override fun onResume() {
        super.onResume()
        adapter.items = loadApps()
        adapter.notifyDataSetChanged()
        handler.post(tick)
        recycler.post { recycler.findViewHolderForAdapterPosition(0)?.itemView?.requestFocus() }
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(tick)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        // Al pulsar Home, volver al inicio de la fila
        recycler.scrollToPosition(0)
        recycler.post { recycler.findViewHolderForAdapterPosition(0)?.itemView?.requestFocus() }
    }

    @Suppress("OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        // Un launcher no debe cerrarse con Atrás
    }

    private fun updateTexts() {
        val h = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
        val hi = when (h) {
            in 5..11 -> "Buenos días"
            in 12..18 -> "Buenas tardes"
            else -> "Buenas noches"
        }
        greeting.text = "$hi, $USER_NAME"
        clock.text = SimpleDateFormat("EEE d MMM  HH:mm", Locale.getDefault()).format(Date())
    }

    private fun buildUi(): View {
        val root = FrameLayout(this)
        root.background = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(Color.parseColor(COLOR_TOP), Color.parseColor(COLOR_BOTTOM))
        )
        // Fondo opcional: pon una imagen llamada bg.png (o bg.jpg) en res/drawable-nodpi
        val bgId = resources.getIdentifier("bg", "drawable", packageName)
        if (bgId != 0) {
            root.addView(ImageView(this).apply {
                scaleType = ImageView.ScaleType.CENTER_CROP
                setImageResource(bgId)
            }, FrameLayout.LayoutParams(-1, -1))
            root.addView(View(this).apply { setBackgroundColor(Color.parseColor("#66000000")) },
                FrameLayout.LayoutParams(-1, -1))
        }

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(56), dp(40), dp(56), dp(32))
            clipChildren = false
            clipToPadding = false
        }

        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val left = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        greeting = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 30f; typeface = Typeface.DEFAULT_BOLD
        }
        val tagline = TextView(this).apply {
            text = TAGLINE; setTextColor(Color.parseColor("#B8C2DB")); textSize = 18f
        }
        left.addView(greeting); left.addView(tagline)
        clock = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 22f; gravity = Gravity.END
        }
        top.addView(left, LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(clock, LinearLayout.LayoutParams(-2, -2))
        col.addView(top, LinearLayout.LayoutParams(-1, -2))

        col.addView(View(this), LinearLayout.LayoutParams(-1, 0, 1f)) // espacio

        col.addView(TextView(this).apply {
            text = "Apps"; setTextColor(Color.parseColor("#B8C2DB"))
            textSize = 16f; typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(4), 0, 0, dp(8))
        })

        recycler = RecyclerView(this).apply {
            layoutManager = LinearLayoutManager(this@MainActivity, RecyclerView.HORIZONTAL, false)
            adapter = this@MainActivity.adapter
            clipChildren = false
            clipToPadding = false
            setPadding(dp(8), dp(24), dp(8), dp(24))
            overScrollMode = View.OVER_SCROLL_NEVER
        }
        col.addView(recycler, LinearLayout.LayoutParams(-1, -2))

        root.addView(col, FrameLayout.LayoutParams(-1, -1))
        return root
    }

    private fun loadApps(): List<AppItem> {
        val pm = packageManager
        val seen = HashSet<String>()
        val raw = ArrayList<Pair<String, AppItem>>()
        for (cat in listOf(Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER)) {
            val q = Intent(Intent.ACTION_MAIN).addCategory(cat)
            for (ri in pm.queryIntentActivities(q, 0)) {
                val pkg = ri.activityInfo.packageName
                if (pkg == packageName || !seen.add(pkg)) continue
                val intent = Intent(Intent.ACTION_MAIN).addCategory(cat)
                    .setClassName(pkg, ri.activityInfo.name)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                val banner = try { ri.activityInfo.loadBanner(pm) } catch (e: Exception) { null }
                val item = AppItem(
                    ri.loadLabel(pm).toString(), intent,
                    banner ?: ri.loadIcon(pm), banner != null
                )
                raw.add(pkg to item)
            }
        }
        val sorted = raw.sortedWith(compareBy(
            { val i = FAVORITES.indexOf(it.first); if (i == -1) Int.MAX_VALUE else i },
            { it.second.label.lowercase() }
        )).map { it.second }.toMutableList()

        sorted.add(
            AppItem(
                "Ajustes",
                Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                resources.getDrawable(android.R.drawable.ic_menu_preferences, theme), false
            )
        )
        return sorted
    }

    inner class AppAdapter : RecyclerView.Adapter<AppAdapter.VH>() {
        var items: List<AppItem> = emptyList()

        inner class VH(val card: FrameLayout, val img: ImageView, val label: TextView) :
            RecyclerView.ViewHolder(card)

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val card = FrameLayout(parent.context).apply {
                layoutParams = RecyclerView.LayoutParams(dp(220), dp(124)).apply {
                    marginEnd = dp(16)
                }
                isFocusable = true
                isClickable = true
                clipChildren = true
            }
            val img = ImageView(parent.context)
            val label = TextView(parent.context).apply {
                setTextColor(Color.WHITE); textSize = 14f; gravity = Gravity.CENTER
                maxLines = 1
            }
            card.addView(img)
            card.addView(label, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM).apply {
                bottomMargin = dp(8)
            })
            return VH(card, img, label)
        }

        override fun onBindViewHolder(h: VH, position: Int) {
            val item = items[position]
            val normal = GradientDrawable().apply {
                cornerRadius = dp(14).toFloat()
                setColor(Color.parseColor("#26FFFFFF"))
            }
            val focused = GradientDrawable().apply {
                cornerRadius = dp(14).toFloat()
                setColor(Color.parseColor("#40FFFFFF"))
                setStroke(dp(3), Color.WHITE)
            }
            h.card.background = normal
            h.img.setImageDrawable(item.image)
            if (item.isBanner) {
                h.img.scaleType = ImageView.ScaleType.CENTER_CROP
                h.img.layoutParams = FrameLayout.LayoutParams(-1, -1)
                h.label.visibility = View.GONE
            } else {
                h.img.scaleType = ImageView.ScaleType.FIT_CENTER
                h.img.layoutParams = FrameLayout.LayoutParams(dp(64), dp(64), Gravity.CENTER_HORIZONTAL)
                    .apply { topMargin = dp(18) }
                h.label.text = item.label
                h.label.visibility = View.VISIBLE
            }
            h.card.setOnFocusChangeListener { v, hasFocus ->
                v.background = if (hasFocus) focused else normal
                v.animate().scaleX(if (hasFocus) 1.12f else 1f)
                    .scaleY(if (hasFocus) 1.12f else 1f)
                    .translationZ(if (hasFocus) dp(8).toFloat() else 0f)
                    .setDuration(120).start()
            }
            h.card.setOnClickListener {
                try { startActivity(item.intent) } catch (e: Exception) { /* app no disponible */ }
            }
        }

        override fun getItemCount() = items.size
    }
}
